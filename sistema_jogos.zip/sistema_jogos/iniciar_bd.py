from app.db import DatabaseConnection
from app.models.usuario import Usuario


def inicializar_banco():
  with DatabaseConnection() as db:
    db.cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                nome TEXT NOT NULL
            );
        """)

    db.cursor.execute("""
            CREATE TABLE IF NOT EXISTS jogos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                genero TEXT NOT NULL,
                plataforma TEXT NOT NULL,
                nota REAL DEFAULT 0.0,
                usuario_id INTEGER NOT NULL,
                FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
            );
        """)

    db.cursor.execute("""
            CREATE TABLE IF NOT EXISTS analises (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                jogo_id INTEGER NOT NULL,
                sinopse TEXT NOT NULL,
                pontos_fortes TEXT,
                pontos_fracos TEXT,
                veredito TEXT,
                usuario_id INTEGER NOT NULL,
                FOREIGN KEY (jogo_id) REFERENCES jogos (id) ON DELETE CASCADE,
                FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
            );
        """)
  print('Tabelas criadas com sucesso!')

  if not Usuario.buscar_por_username('admin'):
    user_teste = Usuario('admin', 'admin123', 'Administrador Teste')
    user_teste.salvar()
    print("Usuário 'admin' criado com sucesso!")


if __name__ == '__main__':
  inicializar_banco()