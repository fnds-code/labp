import os
from app import create_app
from iniciar_bd import inicializar_banco

app = create_app()

if __name__ == '__main__':
    # Verifica se o arquivo do banco de dados já existe na raiz do projeto
    if not os.path.exists('database.db'):
        print("Banco de dados não encontrado. Criando automaticamente...")
        inicializar_banco()
    
    # Inicia o servidor Flask
    app.run(debug=True)