# Sistema de Gerenciamento de Jogos

**Disciplina:** SPOLBP1 - Laboratório de Programação 1  
**Professor:** Igor de Moraes  
**Aluno:** Alexandre Fernandes de Lima  
**Prontuário:** SP319373X  

## Sobre o projeto

Aplicação web MPA desenvolvida com Python, Flask, Jinja2 e SQLite3 para organizar um catálogo pessoal de jogos e publicar análises sobre os jogos cadastrados.

O sistema possui três áreas principais:

- **Usuários:** cadastro, login e logout. As senhas são armazenadas utilizando hash do Werkzeug.
- **Jogos:** cadastro, listagem, busca por título ou gênero, edição e exclusão dos jogos do usuário autenticado.
- **Análises:** cadastro, listagem, edição e exclusão de análises vinculadas aos jogos do próprio usuário.

Também existem proteção de rotas por autenticação, sessões, mensagens flash, cookies para lembrar o nome de usuário e preferência de tema claro/escuro, página personalizada de erro 404 e registros de eventos com o logger do Flask.

Os jogos e as análises podem ser editados pelo próprio usuário. As rotas de edição verificam a propriedade do registro e, no caso das análises, também verificam se o jogo selecionado pertence à conta autenticada.

## Tecnologias utilizadas

- Python
- Flask
- Jinja2
- SQLite3
- HTML
- CSS
- JavaScript
- Bootstrap 5

## Estrutura do projeto

```text
sistema_jogos/
|-- iniciar_bd.py
|-- database.db
|-- run.py
|-- requirements.txt
|-- README.md
|-- app/
    |-- __init__.py
    |-- db.py
    |-- models/
    |-- controllers/
    |-- utils/
    |-- views/
    |-- static/
```

Os Models concentram as consultas SQL parametrizadas. Os Controllers recebem as requisições, realizam validações e chamam os métodos dos Models. As páginas HTML ficam em `app/views/` e utilizam templates Jinja2.

A autenticação das rotas privadas é feita pelo decorator `login_required`, localizado em `app/utils/login_required.py`. A validação de sessão consulta o usuário no banco e disponibiliza o registro autenticado em `g.usuario`.

## Instalação e execução

É necessário ter Python instalado.

1. Abra o terminal na pasta `sistema_jogos`.
2. (Opcional, mas recomendado) Crie e ative um ambiente virtual:

   Linux:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

   Windows:
   ```powershell
   py -m venv .venv
   .venv\\Scripts\\activate
   ```

3. Instale as dependências:

   ```bash
   pip install -r requirements.txt
   ```

4. Inicie a aplicação:

   ```bash
   python run.py
   ```

5. Acesse no navegador:

   http://127.0.0.1:5000

O arquivo `database.db` é utilizado para armazenar os dados. O script `iniciar_bd.py` cria as tabelas caso ainda não existam e cadastra o usuário inicial de teste caso ele ainda não exista.

## Credenciais do usuário inicial de teste

- **Usuário:** `admin`
- **Senha:** `admin123`

Recomenda-se utilizar essas credenciais apenas para testar a aplicação localmente. Para executar em ambiente de publicação, defina uma variável de ambiente `SECRET_KEY` com um valor aleatório e privado.

## Observações

- Cada usuário visualiza, cadastra, edita e exclui apenas seus próprios jogos e análises.
- As análises são vinculadas a um jogo pertencente ao usuário autenticado.
- As senhas são armazenadas com hash, e não em texto puro.
- O banco utiliza SQLite3 com consultas SQL parametrizadas.
- O projeto foi organizado seguindo o padrão Model-View-Controller (MVC) trabalhado na disciplina.
