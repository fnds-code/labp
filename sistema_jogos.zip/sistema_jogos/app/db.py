import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, 'database.db')


class DatabaseConnection:

  def __init__(self, db_path=DB_PATH):
    self.db_path = db_path
    self.conn = None
    self.cursor = None

  def __enter__(self):
    self.conn = sqlite3.connect(self.db_path)
    self.conn.row_factory = sqlite3.Row  # Permite acesso às colunas pelo nome
    self.cursor = self.conn.cursor()
    self.cursor.execute('PRAGMA foreign_keys = ON')  # Ativa chaves estrangeiras
    return self

  def __exit__(self, exc_type, exc_val, exc_tb):
    if exc_type is None:
      self.conn.commit()
    else:
      self.conn.rollback()
    self.conn.close()