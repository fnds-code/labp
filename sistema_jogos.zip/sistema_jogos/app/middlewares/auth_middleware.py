from functools import wraps
from app.models.usuario import Usuario
from flask import flash, g, redirect, session, url_for


def login_required(f):

  @wraps(f)
  def decorated_function(*args, **kwargs):
    user_id = session.get('user_id')
    if not user_id:
      flash('Faça login para acessar esta página.', 'warning')
      return redirect(url_for('auth.login'))

    usuario = Usuario.buscar_por_id(user_id)
    if not usuario:
      session.clear()
      flash('Sessão inválida. Faça login novamente.', 'danger')
      return redirect(url_for('auth.login'))

    g.usuario = usuario
    return f(*args, **kwargs)

  return decorated_function