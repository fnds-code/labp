from app.db import DatabaseConnection
from werkzeug.security import check_password_hash, generate_password_hash


class Usuario:

  def __init__(self, username, password, nome, id=None):
    self.id = id
    self.username = username
    self.password = password
    self.nome = nome

  def salvar(self):
    with DatabaseConnection() as db:
      if self.id is None:
        senha_hash = generate_password_hash(self.password)
        try:
          db.cursor.execute(
              'INSERT INTO usuarios (username, password, nome) VALUES (?, ?,'
              ' ?)',
              (self.username, senha_hash, self.nome),
          )
          self.id = db.cursor.lastrowid
          self.password = senha_hash
          return True
        except Exception:
          return False
      else:
        db.cursor.execute(
            'UPDATE usuarios SET username = ?, password = ?, nome = ? WHERE id'
            ' = ?',
            (self.username, self.password, self.nome, self.id),
        )
        return True

  @classmethod
  def buscar_por_id(cls, id):
    with DatabaseConnection() as db:
      db.cursor.execute(
          'SELECT id, username, password, nome FROM usuarios WHERE id = ?',
          (id,),
      )
      row = db.cursor.fetchone()
      if row:
        return cls(
            id=row['id'],
            username=row['username'],
            password=row['password'],
            nome=row['nome'],
        )
    return None

  @classmethod
  def buscar_por_username(cls, username):
    with DatabaseConnection() as db:
      db.cursor.execute(
          'SELECT id, username, password, nome FROM usuarios WHERE username ='
          ' ?',
          (username,),
      )
      row = db.cursor.fetchone()
      if row:
        return cls(
            id=row['id'],
            username=row['username'],
            password=row['password'],
            nome=row['nome'],
        )
    return None

  @classmethod
  def autenticar(cls, username, password):
    usuario = cls.buscar_por_username(username)
    if usuario and check_password_hash(usuario.password, password):
      return usuario
    return None