from app.db import DatabaseConnection


class Jogo:

  def __init__(self, titulo, genero, plataforma, usuario_id, nota=0.0, id=None):
    self.id = id
    self.titulo = titulo
    self.genero = genero
    self.plataforma = plataforma
    self.nota = nota
    self.usuario_id = usuario_id

  def salvar(self):
    with DatabaseConnection() as db:
      if self.id is None:
        db.cursor.execute(
            'INSERT INTO jogos (titulo, genero, plataforma, nota, usuario_id)'
            ' VALUES (?, ?, ?, ?, ?)',
            (
                self.titulo,
                self.genero,
                self.plataforma,
                self.nota,
                self.usuario_id,
            ),
        )
        self.id = db.cursor.lastrowid
      else:
        db.cursor.execute(
            'UPDATE jogos SET titulo = ?, genero = ?, plataforma = ?, nota = ?'
            ' WHERE id = ? AND usuario_id = ?',
            (
                self.titulo,
                self.genero,
                self.plataforma,
                self.nota,
                self.id,
                self.usuario_id,
            ),
        )
      return True

  @classmethod
  def listar_por_usuario(cls, usuario_id, busca=None):
    with DatabaseConnection() as db:
      if busca:
        query = (
            'SELECT * FROM jogos WHERE usuario_id = ? AND (titulo LIKE ? OR'
            ' genero LIKE ?) ORDER BY id DESC'
        )
        db.cursor.execute(query, (usuario_id, f'%{busca}%', f'%{busca}%'))
      else:
        query = 'SELECT * FROM jogos WHERE usuario_id = ? ORDER BY id DESC'
        db.cursor.execute(query, (usuario_id,))

      rows = db.cursor.fetchall()
      return [
          cls(
              id=r['id'],
              titulo=r['titulo'],
              genero=r['genero'],
              plataforma=r['plataforma'],
              nota=r['nota'],
              usuario_id=r['usuario_id'],
          )
          for r in rows
      ]

  @classmethod
  def buscar_por_id(cls, id, usuario_id):
    with DatabaseConnection() as db:
      db.cursor.execute(
          'SELECT * FROM jogos WHERE id = ? AND usuario_id = ?',
          (id, usuario_id),
      )
      r = db.cursor.fetchone()
      if r:
        return cls(
            id=r['id'],
            titulo=r['titulo'],
            genero=r['genero'],
            plataforma=r['plataforma'],
            nota=r['nota'],
            usuario_id=r['usuario_id'],
        )
    return None

  @classmethod
  def excluir(cls, id, usuario_id):
    with DatabaseConnection() as db:
      db.cursor.execute(
          'DELETE FROM jogos WHERE id = ? AND usuario_id = ?', (id, usuario_id)
      )
      return db.cursor.rowcount > 0