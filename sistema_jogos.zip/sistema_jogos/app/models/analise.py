from app.db import DatabaseConnection


class Analise:

  def __init__(
      self,
      jogo_id,
      sinopse,
      pontos_fortes,
      pontos_fracos,
      veredito,
      usuario_id,
      id=None,
      jogo_titulo=None,
  ):
    self.id = id
    self.jogo_id = jogo_id
    self.jogo_titulo = jogo_titulo
    self.sinopse = sinopse
    self.pontos_fortes = pontos_fortes
    self.pontos_fracos = pontos_fracos
    self.veredito = veredito
    self.usuario_id = usuario_id

  def salvar(self):
    with DatabaseConnection() as db:
      if self.id is None:
        db.cursor.execute(
            'INSERT INTO analises (jogo_id, sinopse, pontos_fortes,'
            ' pontos_fracos, veredito, usuario_id) VALUES (?, ?, ?, ?, ?, ?)',
            (
                self.jogo_id,
                self.sinopse,
                self.pontos_fortes,
                self.pontos_fracos,
                self.veredito,
                self.usuario_id,
            ),
        )
        self.id = db.cursor.lastrowid
      else:
        db.cursor.execute(
            'UPDATE analises SET jogo_id = ?, sinopse = ?, pontos_fortes = ?,'
            ' pontos_fracos = ?, veredito = ? WHERE id = ? AND usuario_id = ?',
            (
                self.jogo_id,
                self.sinopse,
                self.pontos_fortes,
                self.pontos_fracos,
                self.veredito,
                self.id,
                self.usuario_id,
            ),
        )
      return True

  @classmethod
  def listar_por_usuario(cls, usuario_id):
    with DatabaseConnection() as db:
      query = """
                SELECT a.*, j.titulo AS jogo_titulo 
                FROM analises a
                INNER JOIN jogos j ON a.jogo_id = j.id
                WHERE a.usuario_id = ?
                ORDER BY a.id DESC
            """
      db.cursor.execute(query, (usuario_id,))
      rows = db.cursor.fetchall()
      return [
          cls(
              id=r['id'],
              jogo_id=r['jogo_id'],
              jogo_titulo=r['jogo_titulo'],
              sinopse=r['sinopse'],
              pontos_fortes=r['pontos_fortes'],
              pontos_fracos=r['pontos_fracos'],
              veredito=r['veredito'],
              usuario_id=r['usuario_id'],
          )
          for r in rows
      ]

  @classmethod
  def buscar_por_id(cls, id, usuario_id):
    with DatabaseConnection() as db:
      db.cursor.execute(
          """SELECT a.*, j.titulo AS jogo_titulo
             FROM analises a
             INNER JOIN jogos j ON a.jogo_id = j.id
             WHERE a.id = ? AND a.usuario_id = ?""",
          (id, usuario_id),
      )
      r = db.cursor.fetchone()
      if r:
        return cls(
            id=r['id'],
            jogo_id=r['jogo_id'],
            jogo_titulo=r['jogo_titulo'],
            sinopse=r['sinopse'],
            pontos_fortes=r['pontos_fortes'],
            pontos_fracos=r['pontos_fracos'],
            veredito=r['veredito'],
            usuario_id=r['usuario_id'],
        )
    return None

  @classmethod
  def excluir(cls, id, usuario_id):
    with DatabaseConnection() as db:
      db.cursor.execute(
          'DELETE FROM analises WHERE id = ? AND usuario_id = ?',
          (id, usuario_id),
      )
      return db.cursor.rowcount > 0