import logging
import os
from app.controllers.auth_controller import auth_bp
from app.controllers.analise_controller import analise_bp
from app.controllers.jogo_controller import jogo_bp
from app.models.usuario import Usuario
from flask import Flask, g, render_template, session

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VIEWS_DIR = os.path.join(BASE_DIR, 'app', 'views')


def create_app():
  app = Flask(
      __name__, template_folder=VIEWS_DIR, static_folder='static'
  )  # Estáticos e Views

  app.config['SECRET_KEY'] = os.environ.get(
      'SECRET_KEY', 'chave-secreta-apenas-para-desenvolvimento'
  )

  # Configuração do Logger do Flask
  logging.basicConfig(level=logging.INFO)

  # Carrega o usuário logado no objeto 'g' para acesso global nos templates[cite: 11]
  @app.before_request
  def load_logged_in_user():
    user_id = session.get('user_id')
    if user_id:
      g.usuario = Usuario.buscar_por_id(user_id)
    else:
      g.usuario = None

  # Tratamento do Erro 404
  @app.errorhandler(404)
  def page_not_found(e):
    return render_template('404.html'), 404

  # Registro dos Blueprints
  app.register_blueprint(auth_bp)
  app.register_blueprint(jogo_bp)
  app.register_blueprint(analise_bp)

  return app