document.addEventListener("DOMContentLoaded", function() {
    // Procura todos os alertas na página (Flash Messages)
    const alertas = document.querySelectorAll('.alert');
    
    if (alertas.length > 0) {
        // Define um tempo de 5000 milissegundos (5 segundos)
        setTimeout(function() {
            alertas.forEach(function(alerta) {
                // Utiliza a API do Bootstrap para fechar o alerta suavemente
                const bsAlert = new bootstrap.Alert(alerta);
                bsAlert.close();
            });
        }, 5000);
    }
});