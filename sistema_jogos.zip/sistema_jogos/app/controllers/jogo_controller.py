import math

from app.models.jogo import Jogo
from app.middlewares.auth_middleware import login_required
from flask import (
    Blueprint,
    current_app,
    flash,
    g,
    redirect,
    render_template,
    request,
    url_for,
)

jogo_bp = Blueprint('jogo', __name__, url_prefix='/jogos')


@jogo_bp.route('/')
@login_required
def listar():
  busca = request.args.get('busca', '').strip()
  jogos = Jogo.listar_por_usuario(g.usuario.id, busca=busca)
  return render_template('jogos.html', jogos=jogos, busca=busca)


@jogo_bp.route('/novo', methods=['POST'])
@login_required
def novo():
  titulo = request.form.get('titulo', '').strip()
  genero = request.form.get('genero', '').strip()
  plataforma = request.form.get('plataforma', '').strip()
  nota_str = request.form.get('nota', '').strip()

  erros = []
  if not titulo or not genero or not plataforma:
    erros.append('Preencha todos os campos obrigatórios do jogo.')
  if len(titulo) > 100:
    erros.append('O título deve ter no máximo 100 caracteres.')
  if len(genero) > 50:
    erros.append('O gênero deve ter no máximo 50 caracteres.')
  if len(plataforma) > 50:
    erros.append('A plataforma deve ter no máximo 50 caracteres.')

  try:
    nota = 0.0 if not nota_str else float(nota_str)
    if not math.isfinite(nota) or not 0 <= nota <= 10:
      erros.append('A nota deve ser um número entre 0 e 10.')
  except ValueError:
    nota = 0.0
    erros.append('Informe uma nota numérica válida entre 0 e 10.')

  if erros:
    for erro in erros:
      flash(erro, 'danger')
    return redirect(url_for('jogo.listar'))

  jogo = Jogo(
      titulo=titulo,
      genero=genero,
      plataforma=plataforma,
      nota=nota,
      usuario_id=g.usuario.id,
  )
  jogo.salvar()
  current_app.logger.info(
      f"Jogo '{titulo}' cadastrado pelo usuario {g.usuario.username}"
  )
  flash('Jogo cadastrado com sucesso!', 'success')
  return redirect(url_for('jogo.listar'))

@jogo_bp.route('/<int:id>/editar', methods=['GET', 'POST'])
@login_required
def editar(id):
  jogo = Jogo.buscar_por_id(id, g.usuario.id)
  if not jogo:
    flash('Jogo não encontrado.', 'danger')
    return redirect(url_for('jogo.listar'))

  if request.method == 'GET':
    jogos = Jogo.listar_por_usuario(g.usuario.id)
    busca = request.args.get('busca', '').strip()
    return render_template(
        'jogos.html', jogos=jogos, busca=busca, jogo_edicao=jogo
    )

  titulo = request.form.get('titulo', '').strip()
  genero = request.form.get('genero', '').strip()
  plataforma = request.form.get('plataforma', '').strip()
  nota_str = request.form.get('nota', '').strip()
  erros = []

  if not titulo or not genero or not plataforma:
    erros.append('Preencha todos os campos obrigatórios do jogo.')
  if len(titulo) > 100:
    erros.append('O título deve ter no máximo 100 caracteres.')
  if len(genero) > 50:
    erros.append('O gênero deve ter no máximo 50 caracteres.')
  if len(plataforma) > 50:
    erros.append('A plataforma deve ter no máximo 50 caracteres.')
  try:
    nota = float(nota_str)
    if not math.isfinite(nota) or not 0 <= nota <= 10:
      erros.append('A nota deve ser um número entre 0 e 10.')
  except ValueError:
    nota = 0.0
    erros.append('Informe uma nota numérica válida entre 0 e 10.')

  if erros:
    for erro in erros:
      flash(erro, 'danger')
    return redirect(url_for('jogo.editar', id=id))

  jogo.titulo = titulo
  jogo.genero = genero
  jogo.plataforma = plataforma
  jogo.nota = nota
  jogo.salvar()
  current_app.logger.info(
      f"Jogo ID {id} atualizado pelo usuário {g.usuario.username}"
  )
  flash('Jogo atualizado com sucesso!', 'success')
  return redirect(url_for('jogo.listar'))


@jogo_bp.route('/<int:id>/excluir', methods=['POST'])
@login_required
def excluir(id):
  if Jogo.excluir(id, g.usuario.id):
    current_app.logger.info(
        f'Jogo ID {id} excluído pelo usuario {g.usuario.username}'
    )
    flash('Jogo removido com sucesso!', 'success')
  else:
    flash('Erro ao excluir o jogo.', 'danger')
  return redirect(url_for('jogo.listar'))