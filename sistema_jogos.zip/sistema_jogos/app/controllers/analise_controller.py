from app.models.analise import Analise
from app.models.jogo import Jogo
from app.middlewares.auth_middleware import login_required
from flask import (
    Blueprint,
    current_app,
    flash,
    g,
    redirect,
    render_template,
    request,
    url_for,
)

analise_bp = Blueprint('analise', __name__, url_prefix='/analises')


@analise_bp.route('/')
@login_required
def listar():
  analises = Analise.listar_por_usuario(g.usuario.id)
  jogos = Jogo.listar_por_usuario(g.usuario.id)
  return render_template('analises.html', analises=analises, jogos=jogos)


@analise_bp.route('/nova', methods=['POST'])
@login_required
def nova():
  jogo_id_str = request.form.get('jogo_id', '').strip()
  sinopse = request.form.get('sinopse', '').strip()
  pontos_fortes = request.form.get('pontos_fortes', '').strip()
  pontos_fracos = request.form.get('pontos_fracos', '').strip()
  veredito = request.form.get('veredito', '').strip()

  erros = []
  if not jogo_id_str or not sinopse:
    erros.append('Selecione um jogo e preencha a sinopse!')
  if len(sinopse) > 2000:
    erros.append('A sinopse deve ter no máximo 2.000 caracteres.')
  if len(pontos_fortes) > 1000:
    erros.append('Os pontos fortes devem ter no máximo 1.000 caracteres.')
  if len(pontos_fracos) > 1000:
    erros.append('Os pontos fracos devem ter no máximo 1.000 caracteres.')
  if len(veredito) > 120:
    erros.append('O veredito deve ter no máximo 120 caracteres.')
  if erros:
    for erro in erros:
      flash(erro, 'danger')
    return redirect(url_for('analise.listar'))

  try:
    jogo_id = int(jogo_id_str)
  except ValueError:
    flash('Jogo selecionado inválido!', 'danger')
    return redirect(url_for('analise.listar'))

  # Garante que o jogo selecionado pertence ao utilizador logado
  jogo = Jogo.buscar_por_id(jogo_id, g.usuario.id)
  if not jogo:
    flash('Jogo não encontrado na sua lista!', 'danger')
    return redirect(url_for('analise.listar'))

  analise = Analise(
      jogo_id, sinopse, pontos_fortes, pontos_fracos, veredito, g.usuario.id
  )
  analise.salvar()
  current_app.logger.info(
      f"Análise de '{jogo.titulo}' criada por {g.usuario.username}"
  )
  flash('Análise publicada com sucesso!', 'success')

  return redirect(url_for('analise.listar'))


@analise_bp.route('/<int:id>/editar', methods=['GET', 'POST'])
@login_required
def editar(id):
  analise = Analise.buscar_por_id(id, g.usuario.id)
  if not analise:
    flash('Análise não encontrada.', 'danger')
    return redirect(url_for('analise.listar'))

  jogos = Jogo.listar_por_usuario(g.usuario.id)
  if request.method == 'GET':
    analises = Analise.listar_por_usuario(g.usuario.id)
    return render_template(
        'analises.html', analises=analises, jogos=jogos,
        analise_edicao=analise,
    )

  jogo_id_str = request.form.get('jogo_id', '').strip()
  sinopse = request.form.get('sinopse', '').strip()
  pontos_fortes = request.form.get('pontos_fortes', '').strip()
  pontos_fracos = request.form.get('pontos_fracos', '').strip()
  veredito = request.form.get('veredito', '').strip()
  erros = []

  if not jogo_id_str or not sinopse:
    erros.append('Selecione um jogo e preencha a sinopse.')
  if len(sinopse) > 2000:
    erros.append('A sinopse deve ter no máximo 2.000 caracteres.')
  if len(pontos_fortes) > 1000:
    erros.append('Os pontos fortes devem ter no máximo 1.000 caracteres.')
  if len(pontos_fracos) > 1000:
    erros.append('Os pontos fracos devem ter no máximo 1.000 caracteres.')
  if len(veredito) > 120:
    erros.append('O veredito deve ter no máximo 120 caracteres.')

  try:
    jogo_id = int(jogo_id_str)
  except ValueError:
    jogo_id = None
    erros.append('Jogo selecionado inválido.')

  jogo = Jogo.buscar_por_id(jogo_id, g.usuario.id) if jogo_id else None
  if jogo_id and not jogo:
    erros.append('O jogo selecionado não pertence à sua conta.')

  if erros:
    for erro in erros:
      flash(erro, 'danger')
    return redirect(url_for('analise.editar', id=id))

  analise.jogo_id = jogo_id
  analise.sinopse = sinopse
  analise.pontos_fortes = pontos_fortes
  analise.pontos_fracos = pontos_fracos
  analise.veredito = veredito
  analise.salvar()
  current_app.logger.info(
      f'Análise ID {id} atualizada pelo usuário {g.usuario.username}'
  )
  flash('Análise atualizada com sucesso!', 'success')
  return redirect(url_for('analise.listar'))


@analise_bp.route('/<int:id>/excluir', methods=['POST'])
@login_required
def excluir(id):
  if Analise.excluir(id, g.usuario.id):
    current_app.logger.info(
        f'Análise ID {id} excluída pelo usuário {g.usuario.username}'
    )
    flash('Análise removida com sucesso!', 'success')
  else:
    current_app.logger.warning(
        f'Falha ao excluir análise ID {id} pelo usuário {g.usuario.username}'
    )
    flash('Erro ao remover análise.', 'danger')
  return redirect(url_for('analise.listar'))