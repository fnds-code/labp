from app.models.usuario import Usuario
from flask import (
    Blueprint,
    current_app,
    flash,
    make_response,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
  if 'user_id' in session:
    return redirect(url_for('jogo.listar'))

  if request.method == 'POST':
    nome = request.form.get('nome', '').strip()
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '')
    confirm_password = request.form.get('confirm_password', '')

    if not nome or not username or not password:
      flash('Preencha todos os campos obrigatórios!', 'danger')
    elif len(nome) > 100:
      flash('O nome deve ter no máximo 100 caracteres.', 'danger')
    elif len(username) < 3 or len(username) > 30:
      flash('O nome de usuário deve ter entre 3 e 30 caracteres.', 'danger')
    elif len(password) < 8 or len(password) > 128:
      flash('A senha deve ter entre 8 e 128 caracteres.', 'danger')
    elif password != confirm_password:
      flash('As senhas não coincidem!', 'danger')
    else:
      novo_usuario = Usuario(username=username, password=password, nome=nome)
      if novo_usuario.salvar():
        current_app.logger.info(
            f'Novo usuário cadastrado: {username}'
        )  # Logging
        flash('Cadastro realizado com sucesso! Faça login abaixo.', 'success')
        return redirect(url_for('auth.login'))
      else:
        flash('O nome de usuário já está em uso.', 'danger')

  return render_template('cadastro.html')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
  if 'user_id' in session:
    return redirect(url_for('jogo.listar'))

  lembrar_username = request.cookies.get(
      'lembrar_username', ''
  )  # Leitura de Cookie

  if request.method == 'POST':
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '')
    lembrar = request.form.get('lembrar')

    usuario = Usuario.autenticar(username, password)
    if usuario:
      session.clear()
      session['user_id'] = usuario.id  # Sessão padrão exigida pelo prof[cite: 11]
      session['username'] = usuario.username

      current_app.logger.info(
          f'Login bem-sucedido: {username}'
      )  # Logging
      flash(f'Bem-vindo(a), {usuario.nome}!', 'success')

      resp = make_response(redirect(url_for('jogo.listar')))

      # Funcionalidade de Cookie
      if lembrar:
        resp.set_cookie(
            'lembrar_username', username, max_age=30 * 24 * 60 * 60
        )
      else:
        resp.delete_cookie('lembrar_username')

      return resp
    else:
      current_app.logger.warning(
          f'Tentativa de login inválida: {username}'
      )  # Logging
      flash('Usuário ou senha incorretos!', 'danger')

  return render_template('login.html', lembrar_username=lembrar_username)


@auth_bp.route('/logout')
def logout():
  username = session.get('username')
  session.clear()
  current_app.logger.info(f'Logout realizado: {username}')  # Logging
  flash('Sessão encerrada com sucesso.', 'info')
  return redirect(url_for('auth.login'))


@auth_bp.route('/alternar-tema')
def alternar_tema():
  tema_atual = request.cookies.get('tema', 'light')
  novo_tema = 'dark' if tema_atual == 'light' else 'light'

  destino = request.referrer or url_for('jogo.listar')
  resp = make_response(redirect(destino))
  resp.set_cookie('tema', novo_tema, max_age=365 * 24 * 60 * 60)
  return resp