from app.models.jogo import Jogo
from app.models.usuario import Usuario
from flask import Blueprint, redirect, render_template, request, session, url_for

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
  if 'usuario' in session:
    return redirect(url_for('auth.welcome'))

  erro = None
  if request.method == 'POST':
    nome = request.form.get('nome', '').strip()
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '').strip()
    confirm_password = request.form.get('confirm_password', '').strip()

    if not nome or not username or not password:
      erro = 'Preencha todos os campos!'
    elif password != confirm_password:
      erro = 'As senhas não coincidem!'
    else:
      novo_usuario = Usuario(username=username, password=password, nome=nome)
      if novo_usuario.salvar():
        sucesso = 'Cadastro realizado com sucesso! Faça login abaixo.'
        return render_template('login.html', sucesso=sucesso)
      else:
        erro = 'Nome de usuário já está em uso.'

  return render_template('cadastro.html', erro=erro)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
  if 'usuario' in session:
    return redirect(url_for('auth.welcome'))

  erro = None
  if request.method == 'POST':
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '').strip()

    usuario = Usuario.autenticar(username, password)
    if usuario:
      session['usuario'] = usuario.nome
      session['username'] = usuario.username
      return redirect(url_for('auth.welcome'))
    else:
      erro = 'Usuário ou senha incorretos!'

  return render_template('login.html', erro=erro)


@auth_bp.route('/')
@auth_bp.route('/welcome')
def welcome():
  usuario_logado = session.get('usuario')
  jogos = Jogo.listar_todos()
  return render_template('welcome.html', usuario=usuario_logado, jogos=jogos)


@auth_bp.route('/logout')
def logout():
  session.clear()
  return redirect(url_for('auth.login'))