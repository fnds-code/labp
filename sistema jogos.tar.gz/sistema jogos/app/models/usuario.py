import sqlite3
from app.db import ConexaoDB
from werkzeug.security import check_password_hash, generate_password_hash


class Usuario:

  def __init__(self, username, password, nome, id=None):
    self.id = id
    self.username = username
    self.password = password
    self.nome = nome

  # --- MÉTODOS DE INSTÂNCIA ---

  def salvar(self):
    """Insere um novo usuário (se id for None) ou atualiza um existente no banco."""
    with ConexaoDB() as db:
      cursor = db.cursor()

      if self.id is None:
        # Novo registro: Gera hash da senha antes de persistir
        senha_hash = generate_password_hash(self.password)
        try:
          cursor.execute(
              'INSERT INTO usuarios (username, password, nome) VALUES (?, ?,'
              ' ?)',
              (self.username, senha_hash, self.nome),
          )
          # Atualiza os atributos da instância com o ID gerado e a senha em hash
          self.id = cursor.lastrowid
          self.password = senha_hash
          return True
        except sqlite3.IntegrityError:
          return False  # Username duplicado
      else:
        # Atualização de registro existente
        cursor.execute(
            'UPDATE usuarios SET username = ?, password = ?, nome = ? WHERE id ='
            ' ?',
            (self.username, self.password, self.nome, self.id),
        )
        return True

  # --- MÉTODOS DE CLASSE ---

  @classmethod
  def buscar_por_id(cls, id):
    """Busca no banco por ID e retorna uma instância de Usuario."""
    with ConexaoDB() as db:
      cursor = db.cursor()
      cursor.execute(
          'SELECT id, username, password, nome FROM usuarios WHERE id = ?',
          (id,),
      )
      row = cursor.fetchone()

      if row:
        return cls(
            id=row['id'],
            username=row['username'],
            password=row['password'],
            nome=row['nome'],
        )
    return None

  @classmethod
  def buscar_por_username(cls, username):
    """Busca no banco por username e retorna uma instância de Usuario."""
    with ConexaoDB() as db:
      cursor = db.cursor()
      cursor.execute(
          'SELECT id, username, password, nome FROM usuarios WHERE username ='
          ' ?',
          (username,),
      )
      row = cursor.fetchone()

      if row:
        return cls(
            id=row['id'],
            username=row['username'],
            password=row['password'],
            nome=row['nome'],
        )
    return None

  @classmethod
  def autenticar(cls, username, password):
    """Valida o login e retorna a instância do usuário caso as credenciais sejam válidas."""
    usuario = cls.buscar_por_username(username)
    if usuario and check_password_hash(usuario.password, password):
      return usuario
    return None