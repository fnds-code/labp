from app.db import ConexaoDB


class Jogo:

  def __init__(self, titulo, genero, plataforma, nota=0.0, id=None):
    self.id = id
    self.titulo = titulo
    self.genero = genero
    self.plataforma = plataforma
    self.nota = nota

  # --- MÉTODOS DE INSTÂNCIA ---

  def salvar(self):
    """Insere ou atualiza um jogo no banco de dados."""
    with ConexaoDB() as db:
      cursor = db.cursor()
      if self.id is None:
        cursor.execute(
            'INSERT INTO jogos (titulo, genero, plataforma, nota) VALUES (?, ?,'
            ' ?, ?)',
            (self.titulo, self.genero, self.plataforma, self.nota),
        )
        self.id = cursor.lastrowid
      else:
        cursor.execute(
            'UPDATE jogos SET titulo = ?, genero = ?, plataforma = ?, nota = ?'
            ' WHERE id = ?',
            (self.titulo, self.genero, self.plataforma, self.nota, self.id),
        )
      return True

  # --- MÉTODOS DE CLASSE ---

  @classmethod
  def listar_todos(cls):
    """Retorna uma lista com todas as instâncias de Jogo salvas no banco."""
    with ConexaoDB() as db:
      cursor = db.cursor()
      cursor.execute(
          'SELECT id, titulo, genero, plataforma, nota FROM jogos ORDER BY id'
          ' DESC'
      )
      rows = cursor.fetchall()

      jogos = []
      for row in rows:
        jogos.append(
            cls(
                id=row['id'],
                titulo=row['titulo'],
                genero=row['genero'],
                plataforma=row['plataforma'],
                nota=row['nota'],
            )
        )
      return jogos

  @classmethod
  def buscar_por_id(cls, id):
    """Busca um jogo por ID."""
    with ConexaoDB() as db:
      cursor = db.cursor()
      cursor.execute(
          'SELECT id, titulo, genero, plataforma, nota FROM jogos WHERE id = ?',
          (id,),
      )
      row = cursor.fetchone()
      if row:
        return cls(
            id=row['id'],
            titulo=row['titulo'],
            genero=row['genero'],
            plataforma=row['plataforma'],
            nota=row['nota'],
        )
    return None