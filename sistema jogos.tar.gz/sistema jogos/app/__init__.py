import os
from app.db import init_db
from app.middlewares import registrar_middlewares
from flask import Flask


def create_app():
  app = Flask(__name__, template_folder='views')

  app.config['SECRET_KEY'] = (
      os.environ.get('SECRET_KEY') or 'chave-secreta-jogos-dev-2026'
  )

  # 1. Inicializa tabelas do banco de dados
  init_db()

  # 2. Registra os Middlewares da aplicação
  registrar_middlewares(app)

  # 3. Registra os Blueprints (Controllers)
  from app.controllers import auth_bp

  app.register_blueprint(auth_bp)

  return app