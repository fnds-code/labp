import os
from flask import Flask

# Aponta para a pasta 'views' que está dentro de 'app'
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VIEWS_DIR = os.path.join(BASE_DIR, 'app', 'views')


def create_app():
  app = Flask(__name__, template_folder=VIEWS_DIR)

  app.config['SECRET_KEY'] = (
      os.environ.get('SECRET_KEY') or 'chave-secreta-jogos-dev-2026'
  )

  # 1. Inicializa o banco de dados
  from app.db import init_db

  init_db()

  # 2. Registra o Middleware de autenticação
  from app.middlewares.auth_middleware import init_auth_middleware

  init_auth_middleware(app)

  # 3. Registra os Controllers
  from app.controllers.auth_controller import auth_bp

  app.register_blueprint(auth_bp)

  return app