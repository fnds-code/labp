from .auth_middleware import init_auth_middleware


def registrar_middlewares(app):
  """Centraliza o registro de todos os middlewares do sistema."""
  init_auth_middleware(app)


__all__ = ['registrar_middlewares']