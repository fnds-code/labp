from flask import redirect, request, session, url_for


def verificar_autenticacao():
  """Middleware para proteger rotas privadas verificando a sessão do usuário."""
  rotas_publicas = ['auth.login', 'auth.cadastro', 'static']

  if request.endpoint in rotas_publicas or request.endpoint is None:
    return None

  if 'usuario' not in session:
    return redirect(url_for('auth.login'))


def init_auth_middleware(app):
  """Registra o middleware no objeto da aplicação Flask."""
  app.before_request(verificar_autenticacao)