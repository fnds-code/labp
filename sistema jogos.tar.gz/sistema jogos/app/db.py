import sqlite3

DATABASE = 'database.db'


class ConexaoDB:

  def __init__(self, database=DATABASE):
    self.database = database
    self.conn = None

  def __enter__(self):
    self.conn = sqlite3.connect(self.database)
    self.conn.row_factory = sqlite3.Row
    return self.conn

  def __exit__(self, exc_type, exc_val, exc_tb):
    if self.conn:
      if exc_type is not None:
        self.conn.rollback()
      else:
        self.conn.commit()
      self.conn.close()


def init_db():
  """Cria as tabelas e popula dados de teste para a lista inicial."""
  with ConexaoDB() as db:
    cursor = db.cursor()

    # Tabela de Usuários
    cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                nome TEXT NOT NULL
            );
        """)

    # Tabela de Jogos
    cursor.execute("""
            CREATE TABLE IF NOT EXISTS jogos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                genero TEXT NOT NULL,
                plataforma TEXT NOT NULL,
                nota REAL DEFAULT 0.0
            );
        """)

    # Insere jogos iniciais de teste se a tabela estiver vazia
    cursor.execute('SELECT COUNT(*) AS total FROM jogos')
    if cursor.fetchone()['total'] == 0:
      jogos_iniciais = [
          ('The Witcher 3: Wild Hunt', 'RPG', 'PC / PS / Xbox', 9.8),
          ('God of War Ragnarök', 'Ação / Aventura', 'PlayStation', 9.5),
          (
              'The Legend of Zelda: Tears of the Kingdom',
              'Aventura',
              'Nintendo Switch',
              9.7,
          ),
      ]
      cursor.executemany(
          'INSERT INTO jogos (titulo, genero, plataforma, nota) VALUES (?, ?,'
          ' ?, ?)',
          jogos_iniciais,
      )
      