import os
import sqlite3

# Define o caminho absoluto para o banco database.db na raiz do projeto
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, 'database.db')


class ConexaoDB:
  """Gerenciador de contexto para a conexão nativa SQLite."""

  def __enter__(self):
    self.conn = sqlite3.connect(DB_PATH)
    # Permite acessar colunas por nome: row['id'], row['nome']
    self.conn.row_factory = sqlite3.Row
    return self.conn

  def __exit__(self, exc_type, exc_val, exc_tb):
    if exc_type is not None:
      self.conn.rollback()
    else:
      self.conn.commit()
    self.conn.close()


def init_db():
  """Inicializa as tabelas do banco de dados SQLite."""
  with ConexaoDB() as db:
    cursor = db.cursor()

    cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                nome TEXT NOT NULL
            )
        """)

    cursor.execute("""
            CREATE TABLE IF NOT EXISTS jogos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                genero TEXT NOT NULL,
                plataforma TEXT NOT NULL,
                nota REAL DEFAULT 0.0
            )
        """)